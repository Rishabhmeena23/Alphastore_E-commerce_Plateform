from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator,MinValueValidator

STATE_CHOICES = (
    ('Andaman & Nicobar','Andaman & Nicobar'),
    ('Andra Pradesh','Andra Pradesh'),
    ('Arunachal Pradesh','Arunachal Pradesh'),
    ('Assam','Assam'),
    ('Bihar','Bihar'),
    ('Chandigarh','Chandigarh'),
    ('Chattishgarh','Chattishgarh'),
    ('Madhya Pradesh','Madhya Pradesh')
)

class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    locality = models.CharField(max_length=200)
    city = models.CharField(max_length=50)
    zipcode = models.IntegerField()
    state = models.CharField(choices=STATE_CHOICES, max_length=50)

    def __str__(self):
        return str(self.id)
    

# CATEGORY_CHOICES = (
#     ('M','Mobile'),
#     ('L','Laptop'),
#     ('A','Accessories')
# )
class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name
    
class Brand(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

trendingchoice = (
    ('Yes','Yes'),
    ('No','No')
)

class Product(models.Model):
    title = models.CharField(max_length=25)
    selling_price = models.FloatField()
    discounted_price = models.FloatField()
    overview = models.TextField(max_length=85,default='not available')
    description = models.TextField(max_length=1000,default='details not available at the moment')
    brand = models.ForeignKey(Brand,on_delete=models.CASCADE)
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    product_image = models.ImageField(upload_to='productimg')
    trending = models.CharField(max_length=50,choices=trendingchoice ,default='No')

    def __str__(self):
        return str(self.id)
    
    def get_all_by_category():
        return Product.objects.filter(category='Mobile')

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    def __str__(self):
        return str(self.id)
    

STATUS_CHOICES = (
    ('Accepted','Accepted'),
    ('Packed','Packed'),
    ('Packed','Packed'),
    ('Delivered','Delivered'),
    ('Cancel','Cancel')
)

class OrderPlaced(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50,choices=STATUS_CHOICES,default='pending')


